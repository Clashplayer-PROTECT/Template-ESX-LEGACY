Locales['cs'] = {
  ['valid_purchase'] = 'potvrdit nakup?',
  ['yes'] = 'ano',
  ['no'] = 'ne',
  ['not_enough_money'] = 'nemas dostatek penez',
  ['press_access'] = 'stiskni ~INPUT_CONTEXT~ pro pristup k ~y~Holici~s~.',
  ['barber_blip'] = 'Holic',
  ['you_paid'] = 'zaplatil jsi ~g~$%s~s~',
}

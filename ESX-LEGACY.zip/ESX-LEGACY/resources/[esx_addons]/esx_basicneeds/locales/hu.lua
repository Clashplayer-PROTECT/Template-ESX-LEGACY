Locales['hu'] = {
  ['used_bread'] = 'Megettél egy ~y~1x~s~ ~b~kenyeret~s~.',
  ['used_water'] = 'Megittál egy ~y~1x~s~ ~b~vizet~s~.',
}
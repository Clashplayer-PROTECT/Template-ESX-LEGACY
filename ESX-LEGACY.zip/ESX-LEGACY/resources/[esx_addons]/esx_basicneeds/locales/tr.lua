Locales['tr'] = {
	['used_bread'] = '~y~1x~s~ ~b~ekmek~s~ kullandın',
	['used_water'] = '~y~1x~s~ ~b~su~s~ kullandın',
}

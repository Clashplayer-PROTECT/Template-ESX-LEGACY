Locales['pl'] = {
	['veh_released'] = 'pojazd ~g~wyprowadzony~s~ z garażu',
	['veh_stored'] = 'pojazd ~g~oddany~s~ do garażu',
}
